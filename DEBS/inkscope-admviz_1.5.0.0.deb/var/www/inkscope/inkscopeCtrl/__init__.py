__author__ = 'alain.dechorgnat@orange.com'
import Log